//Grupo T1-07
//Jean Lucca - 18203035 - jean.uchaki@edu.pucrs.br
//Leonardo Rubert - 19180465 - leonardo.rubert@edu.pucrs.br
//Lucas Maciel - - 17104154 - lucasvantimaciel@gmail.com

para compilar
jflex .\asdr_lex.flex
javac .\*.java

modo de usar
java Parser .\programa.txt
